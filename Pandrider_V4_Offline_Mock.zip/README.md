# Pandrider V4 – Offline Mock Rider Demo

This is an original offline Android demo app for the Pandrider concept. It does not connect to Foodpanda servers and does not include Foodpanda proprietary code or logos.

## V4 additions
- Login with local demo username/key
- Hidden Mock Settings (tap Pandrider title 7 times)
- Expanded editable rider/order/customer/payment/address/status fields
- Referral URL, arrival minutes, street/city fields
- Editable document/photo reference fields
- Order item add/remove and quantity controls
- Bottom navigation buttons work
- Offline interactive area map on Home
- Map can be dragged/panned, zoomed, and reset
- Rider marker and distinct Customer marker
- Demo area labels such as DHA, Gulberg, Model Town, Johar Town, Liberty, MM Alam, Packages Mall and Hotel

The map is a stylized offline demo map, not live navigation/GPS.

Demo login: rider / 1234
